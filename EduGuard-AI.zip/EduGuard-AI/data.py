
import pandas as pd

# Sample data for our proctoring project
data = {
    "eye_movement": [2, 8, 3, 9, 1, 7, 2, 10, 4, 8],
    "head_movement": [1, 7, 2, 8, 1, 6, 2, 9, 3, 7],
    "multiple_faces": [0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
    "suspicious": [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
}

df = pd.DataFrame(data)

df.to_csv("proctoring_data.csv", index=False)

print("Dataset created successfully!")
print(df.head())