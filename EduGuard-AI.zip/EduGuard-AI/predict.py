
import pandas as pd
from sklearn.tree import DecisionTreeClassifier

# Load the dataset
df = pd.read_csv("proctoring_data.csv")

# Prepare features and target
X = df[["eye_movement", "head_movement", "multiple_faces"]]
y = df["suspicious"]

# Train the model
model = DecisionTreeClassifier(random_state=42)
model.fit(X, y)

print("EduGuard AI - Proctoring Demo")

# Enter sample values
eye = int(input("Enter eye movement score (0-10): "))
head = int(input("Enter head movement score (0-10): "))
faces = int(input("Enter number of additional faces (0 or 1): "))

# Predict
sample = pd.DataFrame(
    [[eye, head, faces]],
    columns=["eye_movement", "head_movement", "multiple_faces"]
)

prediction = model.predict(sample)[0]

if prediction == 1:
    print("Flagged for human review.")
else:
    print("No flag generated.")

print("Note: This demo cannot determine whether someone cheated.")