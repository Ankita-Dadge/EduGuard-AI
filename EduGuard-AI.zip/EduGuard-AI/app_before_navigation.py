
import streamlit as st
import pandas as pd
from sklearn.tree import DecisionTreeClassifier


st.set_page_config(
    page_title="EduGuard AI",
    page_icon="🛡️",
    layout="wide"
)


st.sidebar.title("🛡️ EduGuard AI")
st.sidebar.write("Intelligent Proctoring System")
st.sidebar.divider()

st.sidebar.subheader("Navigation")

page = st.sidebar.radio(
    "Go to",
    [
        "Project Overview",
        "Dataset Summary",
        "Model Evaluation",
        "Sample Prediction"
    ]
)

st.title("🛡️ EduGuard AI")
st.caption("Intelligent Proctoring System | Machine-learning demonstration")
st.markdown("""
### Project Overview

EduGuard AI is a machine-learning demonstration
designed to explore observation data during online exams.

**Main Features**
- Sample dataset analysis
- Machine-learning predictions
- Held-out model evaluation
- Precision and accuracy metrics
- Confusion matrix visualization

**Ethical Safeguards**
- A flag is not proof of cheating.
- Predictions require human review.
- Sample data is artificial.
- No student should be penalized based only on this model.
""")

st.divider()

st.info(
    "This is a learning demo using artificial data. "
    "A flag is not proof of cheating."
)

# Load the sample dataset
df = pd.read_csv("proctoring_data.csv")

st.download_button(
    label="📥 Download Dataset",
    data=df.to_csv(index=False).encode("utf-8"),
    file_name="proctoring_data.csv",
    mime="text/csv"
)

st.subheader("📊 Dataset Summary")

col1, col2, col3 = st.columns(3)

col1.metric("Total Records", len(df))
col2.metric("No Flag Samples", int((df["suspicious"] == 0).sum()))
col3.metric("Flagged Samples", int((df["suspicious"] == 1).sum()))


with st.expander("📋 View Dataset Records"):
    filter_option = st.selectbox(
        "Filter records",
        ["All Records", "No Flag", "Flagged"]
    )

    if filter_option == "No Flag":
        filtered_df = df[df["suspicious"] == 0]
    elif filter_option == "Flagged":
        filtered_df = df[df["suspicious"] == 1]
    else:
        filtered_df = df.copy()

    search_text = st.text_input("🔎 Search dataset records",
    key="dataset_search")

    if search_text:
        filtered_df = filtered_df[
            filtered_df.astype(str)
            .apply(
                lambda row: row.str.contains(
                    search_text,
                    case=False,
                    regex=False
                ).any(),
                axis=1
            )
        ]

    st.dataframe(filtered_df, use_container_width=True)
    st.caption(f"Records displayed: {len(filtered_df)}")
    st.caption(
        "Artificial demonstration data only. "
        "A flag is not proof of cheating."
    )

    if filter_option == "No Flag":
        filtered_df = df[df["suspicious"] == 0]
    elif filter_option == "Flagged":
        filtered_df = df[df["suspicious"] == 1]
    else:
        filtered_df = df

    
search_text = st.text_input("🔎 Search dataset records")

if search_text:
    filtered_df = filtered_df[
        filtered_df.astype(str)
        .apply(lambda row: row.str.contains(search_text, case=False).any(), axis=1)
    ]

st.dataframe(filtered_df, use_container_width=True)
st.caption(f"Records displayed: {len(filtered_df)}")
st.caption(
        "Artificial demonstration data only. A flag is not proof of cheating."
    )
X = df[["eye_movement", "head_movement", "multiple_faces"]]
y = df["suspicious"]

# Train the demonstration model

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, confusion_matrix

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.3,
    random_state=42,
    stratify=y
)

model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)


st.subheader("Held-out Model Evaluation")

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)

report = f"""
EduGuard AI - Model Evaluation Report
=====================================

Model: Decision Tree Classifier
Dataset: Artificial sample data
Training samples: {len(X_train)}
Test samples: {len(X_test)}
Accuracy: {accuracy:.2%}
Precision: {precision:.2%}

Important Notice:
This project uses artificial data for educational purposes.
These scores do not represent real-world cheating detection.
Every flag requires human review.
"""

st.download_button(
    label="📄 Download Evaluation Report",
    data=report,
    file_name="EduGuard_AI_Evaluation_Report.txt",
    mime="text/plain"
)

col1, col2, col3 = st.columns(3)

col1.metric("Test Samples", len(X_test))
col2.metric("Accuracy", f"{accuracy:.2%}")
col3.metric("Precision", f"{precision:.2%}")

st.subheader("📈 Model Performance")

performance_df = pd.DataFrame({
    "Metric": ["Accuracy", "Precision"],
    "Score": [accuracy, precision]
})

st.bar_chart(
    performance_df.set_index("Metric"),
    y="Score",
    y_label="Score (0 to 1)"
)

cm = confusion_matrix(y_test, y_pred, labels=[0, 1])



st.divider()
st.subheader("🔎 Try a Sample Prediction")
st.warning(
    "Educational demo only: model predictions are not proof of cheating. "
    "All flagged results require human review."
)
st.write(
    "Adjust the sample observation values below and click "
    "**Run Demo** to see the model's demonstration output."
)

col1, col2 = st.columns(2)


with col1:
    eye = st.slider(
        "Eye movement score",
        min_value=0,
        max_value=10,
        value=3,
        key="eye_slider"
    )

with col2:
    head = st.slider(
        "Head movement score",
        min_value=0,
        max_value=10,
        value=2,
        key="head_slider"
    )


faces = st.selectbox(
    "Additional faces detected (sample input)",
    [0, 1],
    key="faces_select"
)


# Initialize default values
if "eye_slider" not in st.session_state:
    st.session_state["eye_slider"] = 3

if "head_slider" not in st.session_state:
    st.session_state["head_slider"] = 2

if "faces_select" not in st.session_state:
    st.session_state["faces_select"] = 0

def reset_sample_values():
    st.session_state["eye_slider"] = 3
    st.session_state["head_slider"] = 2
    st.session_state["faces_select"] = 0

st.button(
    "🔄 Reset Sample Values",
    on_click=reset_sample_values
)    


if st.button("Run Demo", type="primary"):
    sample = pd.DataFrame(
        [[eye, head, faces]],
        columns=["eye_movement", "head_movement", "multiple_faces"]
    )

    prediction = model.predict(sample)[0]

    st.subheader("Demo Result")

    if prediction == 1:
        st.warning(
            "Flagged for human review — this is only a model output, "
            "not evidence of cheating."
        )
    else:
        st.success(
            "No flag generated for this sample. "
            "This does not prove that no misconduct occurred."
        )

    st.caption(
        "Educational demonstration using artificial data. "
        "Never use this result alone to accuse or penalize a student."
    )
    
st.divider()
st.subheader("Model Evaluation")

st.write("Training samples:", len(X_train))
st.write("Model: Decision Tree Classifier")
st.write("Dataset: Artificial sample data (500 rows)")

st.warning(
    "The current dataset is very small. "
    "Evaluation scores do not represent real-world performance."
)

from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

st.divider()

st.subheader("Held-out Confusion Matrix")

cm = confusion_matrix(y_test, y_pred, labels=[0, 1])

st.write("Rows: Actual labels | Columns: Predicted labels")
st.write("Label 0: No flag | Label 1: Flagged for review")





fig, ax = plt.subplots(figsize=(6, 4))
image = ax.imshow(cm, cmap="Blues")

ax.set_title("Held-out Confusion Matrix")
ax.set_xlabel("Predicted label")
ax.set_ylabel("Actual label")
ax.set_xticks([0, 1], labels=["No flag (0)", "Flag (1)"])
ax.set_yticks([0, 1], labels=["No flag (0)", "Flag (1)"])

fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)

for i in range(2):
    for j in range(2):
        ax.text(j, i, str(cm[i, j]), ha="center", va="center")

st.pyplot(fig)
plt.close(fig)
st.divider()

st.subheader("📝 Project Conclusion")

st.write(
    "EduGuard AI demonstrates how machine learning can identify "
    "suspicious patterns in sample exam observations. The model uses "
    "artificial data for educational purposes. Its predictions are "
    "not proof of cheating, and every flag must be reviewed by a human."
)

st.caption(
    "This matrix uses held-out test rows. The artificial labels "
    "cannot establish real-world cheating detection performance."
)

