

import pandas as pd
import random

random.seed(42)

rows = []

for _ in range(500):
    eye_movement = random.randint(0, 10)
    head_movement = random.randint(0, 10)
    multiple_faces = random.randint(0, 1)

    # Artificial rule for educational demonstration only.
    demo_label = int(
        (eye_movement >= 8 and head_movement >= 7)
        or multiple_faces == 1
    )

    rows.append({
        "eye_movement": eye_movement,
        "head_movement": head_movement,
        "multiple_faces": multiple_faces,
        "suspicious": demo_label
    })

df = pd.DataFrame(rows)
df.to_csv("proctoring_data.csv", index=False)

print("Demo dataset created successfully!")
print("Total rows:", len(df))
print(df.head())
print("\nLabel counts:")
print(df["suspicious"].value_counts().sort_index())