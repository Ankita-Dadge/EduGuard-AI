
import streamlit as st
import pandas as pd
from sklearn.tree import DecisionTreeClassifier


st.title("EduGuard AI")
st.subheader("Intelligent Proctoring System")

st.markdown("""
### Project Overview

EduGuard AI is a machine-learning demonstration
designed to explore observation data during online exams.

**Main Features**
- Sample dataset analysis
- Machine-learning predictions
- Held-out model evaluation
- Precision and accuracy metrics
- Confusion matrix visualization

**Ethical Safeguards**
- A flag is not proof of cheating.
- Predictions require human review.
- Sample data is artificial.
- No student should be penalized based only on this model.
""")

st.divider()

st.info(
    "This is a learning demo using artificial data. "
    "A flag is not proof of cheating."
)

# Load the sample dataset
df = pd.read_csv("proctoring_data.csv")

X = df[["eye_movement", "head_movement", "multiple_faces"]]
y = df["suspicious"]

# Train the demonstration model

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, confusion_matrix

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.3,
    random_state=42,
    stratify=y
)

model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

st.subheader("Held-out Model Evaluation")
st.write("Test samples:", len(X_test))
st.write("Accuracy:", accuracy_score(y_test, y_pred))
st.write(
    "Precision:",
    precision_score(y_test, y_pred, zero_division=0)
)

cm = confusion_matrix(y_test, y_pred, labels=[0, 1])


st.write("Enter sample observations below.")

eye = st.slider("Eye movement score", 0, 10, 3)app.py
head = st.slider("Head movement score", 0, 10, 2)
faces = st.selectbox("Additional faces detected", [0, 1])

if st.button("Run Demo"):
    sample = pd.DataFrame(
        [[eye, head, faces]],
        columns=["eye_movement", "head_movement", "multiple_faces"]
    )

    prediction = model.predict(sample)[0]

    if prediction == 1:
        st.warning("Flagged for human review.")
    else:
        st.success("No flag generated.")

    st.caption(
        "Predictions use artificial sample data and must not be "
        "used to accuse or penalize anyone."
    )
    
st.divider()
st.subheader("Model Evaluation")

st.write("Training samples:", len(X))
st.write("Model: Decision Tree Classifier")
st.write("Dataset: Artificial sample data")

st.warning(
    "The current dataset is very small. "
    "Evaluation scores do not represent real-world performance."
)

from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

st.divider()

st.subheader("Held-out Confusion Matrix")

cm = confusion_matrix(y, model.predict(X), labels=[0, 1])

st.write("Rows: Actual labels | Columns: Predicted labels")
st.write("Label 0: No flag | Label 1: Flagged for review")




fig, ax = plt.subplots()
ax.imshow(cm)

ax.set_xlabel("Predicted label")
ax.set_ylabel("Actual label")
ax.set_xticks([0, 1])
ax.set_yticks([0, 1])

for i in range(2):
    for j in range(2):
        ax.text(j, i, str(cm[i, j]), ha="center", va="center")

st.pyplot(fig)
plt.close(fig)

st.caption(
    "This matrix uses held-out test rows. The artificial labels "
    "cannot establish real-world cheating detection performance."
)

