
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    classification_report
)

# Load dataset
df = pd.read_csv("proctoring_data.csv")

X = df[["eye_movement", "head_movement", "multiple_faces"]]
y = df["suspicious"]

# Keep separate training and test data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.3,
    random_state=42,
    stratify=y
)

# Train model only on training data
model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)

# Evaluate on unseen test rows
y_pred = model.predict(X_test)

print("EduGuard AI - Model Evaluation")
print("--------------------------------")
print("Training rows:", len(X_train))
print("Testing rows:", len(X_test))
print("Accuracy:", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(
    y_test, y_pred, zero_division=0
))
print("\nDetailed Report:")
print(classification_report(
    y_test, y_pred, zero_division=0
))

from sklearn.metrics import confusion_matrix

# Display confusion matrix
cm = confusion_matrix(y_test, y_pred, labels=[0, 1])

print("\nConfusion Matrix:")
print(cm)

print("\nInterpretation:")
print("Rows represent actual labels: 0 and 1")
print("Columns represent predicted labels: 0 and 1")
